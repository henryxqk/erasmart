// 监听来自popup的消息
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === "performAction") {
    // 在这里执行您想要的操作，例如修改页面内容
    document.body.style.backgroundColor = '#f0f0f0';
    
    // 发送响应回popup
    sendResponse({status: "操作已执行"});
  }
});

console.log('Content script已加载');