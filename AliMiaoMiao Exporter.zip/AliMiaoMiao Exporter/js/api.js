// API环境配置
const API_ENV = {
  test: 'http://api.lsai.test',
  prod: 'https://xibo.syncotekmarket.com:18888' // 生产环境域名需要替换为实际的
};

// 当前环境，默认为测试环境
let currentEnv = 'prod';

// 设置当前环境
window.setApiEnv = function(env) {
  if (API_ENV[env]) {
    currentEnv = env;
  }
};

// 获取完整的API URL
function getFullUrl(path) {
  return `${API_ENV[currentEnv]}${path}`;
}

// 通用API请求函数
window.request = async function(path, options = {}) {
  // 默认请求配置
  const defaultOptions = {
    headers: {
      'Content-Type': 'application/json'
    }
  };

  // 合并请求配置
  const finalOptions = {
    ...defaultOptions,
    ...options,
    headers: {
      ...defaultOptions.headers,
      ...(options.headers || {})
    }
  };

  // 发送请求
  const response = await fetch(getFullUrl(path), finalOptions);
  
  // 检查网络请求状态
  if (!response.ok) {
    throw new Error(`网络请求失败: ${response.status} ${response.statusText}`);
  }
  
  const data = await response.json();
  console.log('API响应:', data); // 添加响应日志

  // 处理响应
  if (data.code === 0) {
    return data;
  } else {
    throw new Error(data.msg || `请求失败(${data.code})`);
  }
};

// 消息抓取器类
class MessageScraper {
  static async getMessages() {
    const messages = [];
    const messageItems = document.querySelectorAll('.message-item-wrapper');
    
    messageItems.forEach(item => {
      const message = this.parseMessageItem(item);
      if (message) {
        messages.push(message);
      }
    });
    
    return messages;
  }

  static parseMessageItem(item) {
    const isLeft = item.classList.contains('item-left');
    const messageContent = item.querySelector('.session-rich-content.text')?.textContent?.trim();
    const timeStamp = item.querySelector('.item-base-info span:last-child')?.textContent?.trim();
    const senderName = item.querySelector('.item-base-info .name')?.textContent?.trim();
    
    if (messageContent) {
      return {
        sender: senderName || (isLeft ? '买家' : '卖家'),
        time: timeStamp || '',
        content: messageContent,
        textFormat: `${senderName || (isLeft ? '买家' : '卖家')} (${timeStamp || ''}): ${messageContent}\n`
      };
    }
    return null;
  }
}

// 页面信息抓取器类
class PageScraper {
  static getPageInfo() {
    return {
      title: document.title,
      url: window.location.href
    };
  }
}

// 主抓取函数
async function scrapeData() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    const result = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      function: () => {
        const messages = MessageScraper.getMessages();
        const pageInfo = PageScraper.getPageInfo();
        
        return {
          ...pageInfo,
          messages
        };
      }
    });
    
    return result[0].result;
  } catch (error) {
    console.error('抓取失败:', error);
    throw error;
  }
}

// 导出函数
window.scrapeData = scrapeData;