document.addEventListener('DOMContentLoaded', function() {
  const actionButton = document.getElementById('actionButton');
  
  // 简单的Toast提示函数
  function showToast(message, type) {
    if (window.toast) {
      window.toast[type](message);
    } else {
      console.log(`${type}: ${message}`);
      alert(message);
    }
  }
  
  actionButton.addEventListener('click', async () => {
    try {
      actionButton.disabled = true;
      actionButton.textContent = '抓取中...';
      
      // 获取当前标签页
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      console.log('当前标签页:', tab);
      
      // 执行抓取脚本
      const result = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        function: () => {
          const messages = [];
          const messageItems = document.querySelectorAll('.message-item-wrapper');
          console.log('找到消息元素:', messageItems.length);
          
          messageItems.forEach(item => {
            const isLeft = item.classList.contains('item-left');
            const messageContent = item.querySelector('.session-rich-content.text')?.textContent?.trim();
            const timeStamp = item.querySelector('.item-base-info span:last-child')?.textContent?.trim();
            const senderName = item.querySelector('.item-base-info .name')?.textContent?.trim();
            
            if (messageContent) {
              messages.push({
                sender: senderName || (isLeft ? '买家' : '卖家'),
                time: timeStamp || '',
                content: messageContent,
                textFormat: `${senderName || (isLeft ? '买家' : '卖家')} (${timeStamp || ''}): ${messageContent}\n`
              });
            }
          });

          return {
            title: document.title,
            url: window.location.href,
            messages: messages
          };
        }
      });
      
      console.log('抓取结果:', result);
      
      if (!result || !result[0] || !result[0].result) {
        throw new Error('抓取数据为空');
      }
      
      const data = result[0].result;
      
      // 保存为文件
      const textContent = `标题：${data.title}\n` +
                         `URL：${data.url}\n` +
                         `抓取时间：${new Date().toLocaleString()}\n\n` +
                         `=== 聊天记录 ===\n\n` +
                         data.messages.map(msg => msg.textFormat).join('');
      
      const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `chat_history_${new Date().toISOString().slice(0,19).replace(/:/g, '-')}.txt`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      showToast('聊天记录已保存！', 'success');
      
    } catch (error) {
      console.error('抓取失败:', error);
      showToast('抓取失败，请重试', 'error');
    } finally {
      actionButton.disabled = false;
      actionButton.textContent = '开始抓取';
    }
  });
});