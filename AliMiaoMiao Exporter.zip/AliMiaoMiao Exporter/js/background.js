chrome.runtime.onInstalled.addListener(function() {
  console.log('扩展已安装');
  
  // 可以在这里设置初始状态或执行其他安装时的操作
  chrome.storage.local.set({
    isEnabled: true,
    isLoggedIn: true
  }, function() {
    console.log('初始状态已设置');
  });
});

// 监听来自content script或popup的消息
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === "getStatus") {
    chrome.storage.local.get('isEnabled', function(data) {
      sendResponse({status: data.isEnabled});
    });
    return true; // 保持消息通道开放，以便异步发送响应
  }
});