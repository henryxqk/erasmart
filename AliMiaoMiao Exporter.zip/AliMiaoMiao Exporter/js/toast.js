// Toast提示组件
class Toast {
  constructor() {
    this.init();
  }

  init() {
    // 创建toast容器
    this.container = document.createElement('div');
    this.container.className = 'toast-container';
    document.body.appendChild(this.container);

    // 添加样式
    const style = document.createElement('style');
    style.textContent = `
      .toast-container {
        position: fixed;
        top: 20px;
        left: 50%;
        transform: translateX(-50%);
        z-index: 9999;
      }

      .toast {
        padding: 12px 24px;
        margin-bottom: 10px;
        border-radius: 4px;
        color: #fff;
        font-size: 14px;
        line-height: 1.5;
        min-width: 200px;
        text-align: center;
        animation: toast-in 0.3s ease, toast-out 0.3s ease 2.7s;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
      }

      .toast.success {
        background-color: #52c41a;
      }

      .toast.error {
        background-color: #ff4d4f;
      }

      .toast.warning {
        background-color: #faad14;
      }

      .toast.info {
        background-color: #1890ff;
      }

      @keyframes toast-in {
        from {
          opacity: 0;
          transform: translateY(-20px);
        }
        to {
          opacity: 1;
          transform: translateY(0);
        }
      }

      @keyframes toast-out {
        from {
          opacity: 1;
          transform: translateY(0);
        }
        to {
          opacity: 0;
          transform: translateY(-20px);
        }
      }
    `;
    document.head.appendChild(style);
  }

  show(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    this.container.appendChild(toast);

    // 3秒后移除toast
    setTimeout(() => {
      toast.addEventListener('animationend', (e) => {
        if (e.animationName === 'toast-out') {
          this.container.removeChild(toast);
        }
      });
    }, 3000);
  }

  success(message) {
    this.show(message, 'success');
  }

  error(message) {
    this.show(message, 'error');
  }

  warning(message) {
    this.show(message, 'warning');
  }

  info(message) {
    this.show(message, 'info');
  }
}

// 创建全局toast实例
window.toast = new Toast();