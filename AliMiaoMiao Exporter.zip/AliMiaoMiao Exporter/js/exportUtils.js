class MessageExporter {
  static formatContent(data) {
    let textContent = `标题：${data.title}\n`;
    textContent += `URL：${data.url}\n`;
    textContent += `抓取时间：${new Date().toLocaleString()}\n`;
    textContent += `\n=== 聊天记录 ===\n\n`;
    
    data.messages.forEach(msg => {
      textContent += msg.textFormat;
    });
    
    return textContent;
  }

  static exportToTxt(data, filename) {
    const textContent = this.formatContent(data);
    const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = filename || `chat_history_${new Date().toISOString().slice(0,19).replace(/:/g, '-')}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }
}

window.MessageExporter = MessageExporter;